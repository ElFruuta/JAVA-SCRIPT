for(var i = 0; i < 100; i++) {
    if ( i % 3 === 0 ) {
        console.log(i);
    }
}
