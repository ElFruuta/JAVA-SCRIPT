//Numeros impares del 1 al 20//

for (var i = 0; i <= 20; i++) {
    if ( i % 2 === 1 ) {
        console.log("Es impar");
    }
    else {
        console.log(i);
        }
}