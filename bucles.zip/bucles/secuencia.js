var options = [4, 2.5, 1, -0.5, -2, -3.5]

for ( i = 0; i < options.length; i++ ) {
    console.log (options[i]);
}   
